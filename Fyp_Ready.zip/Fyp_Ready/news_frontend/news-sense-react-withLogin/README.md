# Fake News Detection System

## Project Info

This project is a custom-built fake news detection platform using:

- React + Vite
- TypeScript
- Tailwind CSS
- shadcn/ui
