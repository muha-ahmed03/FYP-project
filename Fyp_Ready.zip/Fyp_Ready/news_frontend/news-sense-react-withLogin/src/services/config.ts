export const API_BASE_URL = "http://127.0.0.1:8000";

export const API_ENDPOINTS = {
  ALL_NEWS: `${API_BASE_URL}/all_news`,
  PREDICT: `${API_BASE_URL}/predict`, 
  VALIDATE: `${API_BASE_URL}/validate`,
  UNVALIDATED: `${API_BASE_URL}/unvalidated`
};
