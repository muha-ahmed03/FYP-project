// src/store/authSlice.ts
import { createSlice, PayloadAction, createAsyncThunk } from '@reduxjs/toolkit'

interface User {
  username: string
  email?: string
}

interface AuthState {
  isAuthenticated: boolean
  user: User | null
  isLoading: boolean
}

const initialState: AuthState = {
  isAuthenticated: false,
  user: null,
  isLoading: false,
}

// Hard-coded credentials
const VALID_CREDENTIALS = {
  username: 'admin',
  password: 'admin123'
}

// Async thunk for login with proper return values
export const loginUser = createAsyncThunk(
  'auth/loginUser',
  async ({ username, password }: { username: string; password: string }, { rejectWithValue }) => {
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    if (username === VALID_CREDENTIALS.username && password === VALID_CREDENTIALS.password) {
      const user = { username };
      // Persist to localStorage
      localStorage.setItem('isAuthenticated', 'true');
      localStorage.setItem('user', JSON.stringify(user));
      return user;
    } else {
      return rejectWithValue('Invalid credentials');
    }
  }
)

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    logout: (state) => {
      state.isAuthenticated = false
      state.user = null
      state.isLoading = false
      // Clear localStorage
      localStorage.removeItem('isAuthenticated')
      localStorage.removeItem('user')
    },
    checkAuthStatus: (state) => {
      // Check localStorage on app start
      const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true'
      const user = localStorage.getItem('user')
      
      if (isAuthenticated && user) {
        state.isAuthenticated = true
        state.user = JSON.parse(user)
      }
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(loginUser.pending, (state) => {
        state.isLoading = true
      })
      .addCase(loginUser.fulfilled, (state, action) => {
        state.isAuthenticated = true
        state.user = action.payload
        state.isLoading = false
      })
      .addCase(loginUser.rejected, (state) => {
        state.isAuthenticated = false
        state.user = null
        state.isLoading = false
      })
  }
})

export const { logout, checkAuthStatus } = authSlice.actions
export default authSlice.reducer