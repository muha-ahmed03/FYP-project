
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import Navigation from "@/components/Navigation";
import LoadingSpinner from "@/components/LoadingSpinner";
import { useToast } from "@/hooks/use-toast";

interface NewsItem {
  index: number;
  news: string;
  pred: string;
  validation_pred?: string;
  validated: boolean;
}

const NewsArchive = () => {
  const [newsItems, setNewsItems] = useState<NewsItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchNewsItems();
  }, []);

  const fetchNewsItems = async () => {
    try {
      const response = await fetch("http://127.0.0.1:8000/all_news");
      
      if (!response.ok) {
        throw new Error("Failed to fetch news items");
      }

      const data = await response.json();
      setNewsItems(data);
    } catch (error) {
      console.error("Error fetching news:", error);
      toast({
        title: "Error Loading News",
        description: "Unable to load news archive. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const truncateText = (text: string, maxLength: number = 150) => {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + "...";
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="flex items-center justify-center min-h-[60vh]">
          <LoadingSpinner size="lg" text="Loading news archive..." />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4 font-inter">
            News Archive
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Browse through analyzed news articles and contribute to validation efforts.
          </p>
          <div className="mt-6 bg-white rounded-lg shadow-sm p-4 max-w-md mx-auto">
            <p className="text-sm text-gray-600">
              Total Articles: <span className="font-semibold text-primary">{newsItems.length}</span>
            </p>
          </div>
        </div>

        {newsItems.length === 0 ? (
          <div className="text-center py-16">
            <div className="text-6xl mb-4">📰</div>
            <h3 className="text-xl font-medium text-gray-900 mb-2">No Articles Found</h3>
            <p className="text-gray-600 mb-6">
              No news articles are available in the archive yet.
            </p>
            <Link
              to="/classify"
              className="inline-flex items-center px-6 py-3 bg-primary text-white rounded-lg hover:bg-blue-600 transition-colors"
            >
              Classify Your First Article
            </Link>
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {newsItems.map((item) => (
              <div key={item.index} className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-200">
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <span className="text-sm text-gray-500 font-medium">
                      Article #{item.index}
                    </span>
                    <div className="flex space-x-2">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        item.pred === "Fake News" 
                          ? "bg-red-100 text-red-800" 
                          : "bg-green-100 text-green-800"
                      }`}>
                        {item.pred}
                      </span>
                      {item.validated && (
                        <span className="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                          Validated
                        </span>
                      )}
                    </div>
                  </div>
                  
                  <p className="text-gray-700 mb-6 leading-relaxed">
                    {truncateText(item.news)}
                  </p>
                  
                  {item.validation_pred && (
                    <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                      <p className="text-sm text-gray-600">
                        <span className="font-medium">Human Validation:</span> {item.validation_pred}
                      </p>
                    </div>
                  )}
                  
                  <Link
                    to={`/news/${item.index}`}
                    className="inline-flex items-center px-4 py-2 bg-primary text-white text-sm font-medium rounded-lg hover:bg-blue-600 transition-colors"
                  >
                    View Details
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default NewsArchive;
