import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import Navigation from "@/components/Navigation";
import LoadingSpinner from "@/components/LoadingSpinner";
import { API_ENDPOINTS } from "@/services/config";

interface PredictionResult {
  subject: string;
  title: string;
  news: string;
  pred: string;
  validation_pred: string;
  validated: boolean;
}

const ClassifyNews = () => {
  const [subject, setSubject] = useState("");
  const [title, setTitle] = useState("");
  const [text, setText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<PredictionResult | null>(null);
  const [showModal, setShowModal] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!subject.trim() || !title.trim() || !text.trim()) {
      toast({
        title: "Missing Information",
        description: "Please fill in all fields: subject, title, and content.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    
    try {
      const response = await fetch(API_ENDPOINTS.PREDICT, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ 
          subject: subject.trim(),
          title: title.trim(),
          text: text.trim()
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to analyze news");
      }

      const data = await response.json();
      setResult(data);
      setShowModal(true);
    } catch (error) {
      console.error("Error analyzing news:", error);
      toast({
        title: "Analysis Failed",
        description: "Unable to connect to the analysis service. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const resetForm = () => {
    setSubject("");
    setTitle("");
    setText("");
    setResult(null);
    setShowModal(false);
  };

  const isFormValid = subject.trim() && title.trim() && text.trim() && !isLoading;

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4 font-inter">
            Classify News Article
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Submit a news article for AI-powered analysis to determine if it's genuine or potentially fake news.
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-200">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-2">
                Subject/Category *
              </label>
              <input
                type="text"
                id="subject"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Enter the news subject or category (e.g., Politics, Technology, Sports)..."
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent transition-colors"
                disabled={isLoading}
              />
            </div>

            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-2">
                News Title *
              </label>
              <input
                type="text"
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter the news headline..."
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent transition-colors"
                disabled={isLoading}
              />
            </div>

            <div>
              <label htmlFor="text" className="block text-sm font-medium text-gray-700 mb-2">
                News Content *
              </label>
              <textarea
                id="text"
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Paste the full news article content here..."
                rows={10}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent transition-colors resize-y"
                disabled={isLoading}
              />
              <p className="text-sm text-gray-500 mt-1">
                Minimum 10 characters required
              </p>
            </div>

            <div className="flex justify-center">
              <button
                type="submit"
                disabled={!isFormValid}
                className="px-8 py-3 bg-primary text-white font-medium rounded-lg hover:bg-blue-600 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center space-x-2"
              >
                {isLoading ? (
                  <>
                    <LoadingSpinner size="sm" />
                    <span>Analyzing...</span>
                  </>
                ) : (
                  <span>Analyze News</span>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Result Modal */}
      {showModal && result && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full p-6 animate-fade-in">
            <div className="text-center">
              <div className={`w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center ${
                result.pred === "Fake News" ? "bg-red-100" : "bg-green-100"
              }`}>
                {result.pred === "Fake News" ? (
                  <span className="text-2xl">⚠️</span>
                ) : (
                  <span className="text-2xl">✅</span>
                )}
              </div>
              
              <h3 className="text-2xl font-bold mb-2">
                Analysis Complete
              </h3>
              
              <div className={`inline-block px-4 py-2 rounded-full text-sm font-medium mb-4 ${
                result.pred === "Fake News" 
                  ? "bg-red-100 text-red-800" 
                  : "bg-green-100 text-green-800"
              }`}>
                {result.pred}
              </div>

              {/* Show analyzed content summary */}
              <div className="text-left bg-gray-50 rounded-lg p-4 mb-6">
                <div className="space-y-2">
                  <div>
                    <span className="text-xs text-gray-500 uppercase tracking-wide">Subject:</span>
                    <p className="text-sm font-medium text-gray-900">{result.subject}</p>
                  </div>
                  <div>
                    <span className="text-xs text-gray-500 uppercase tracking-wide">Title:</span>
                    <p className="text-sm font-medium text-gray-900">{result.title}</p>
                  </div>
                </div>
              </div>
              
              <div className="flex space-x-3">
                <button
                  onClick={resetForm}
                  className="flex-1 px-4 py-2 bg-primary text-white rounded-lg hover:bg-blue-600 transition-colors"
                >
                  Analyze Another
                </button>
                <button
                  onClick={() => setShowModal(false)}
                  className="flex-1 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ClassifyNews;