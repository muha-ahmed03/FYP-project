
import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import Navigation from "@/components/Navigation";
import LoadingSpinner from "@/components/LoadingSpinner";
import { useToast } from "@/hooks/use-toast";

interface NewsItem {
  index: number;
  news: string;
  pred: string;
  validation_pred?: string;
  validated: boolean;
}

const NewsDetails = () => {
  const { id } = useParams<{ id: string }>();
  const [newsItem, setNewsItem] = useState<NewsItem | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchNewsItem();
  }, [id]);

  const fetchNewsItem = async () => {
    try {
      const response = await fetch("http://127.0.0.1:8000/all_news");
      
      console.log("Fetch NEWS ITEM RESPONSEEEEEEEEEEEEEEEEEEE:", response);
      
      if (!response.ok) {
        throw new Error("Failed to fetch news items");
      }

      const data = await response.json();
      const item = data.find((news: NewsItem) => news.index.toString() === id);
      
      if (!item) {
        throw new Error("News item not found");
      }
      
      setNewsItem(item);
    } catch (error) {
      console.error("Error fetching news item:", error);
      toast({
        title: "Error Loading Article",
        description: "Unable to load the requested article.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleValidation = async (validationChoice: string) => {
    if (!newsItem) return;

    setIsSubmitting(true);
    
    try {
      const response = await fetch("http://127.0.0.1:8000/validate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          index: newsItem.index,
          validation_pred: validationChoice,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to submit validation");
      }

      setShowSuccessModal(true);
      
      setNewsItem(prev => prev ? {
        ...prev,
        validated: true,
        validation_pred: validationChoice
      } : null);
      
    } catch (error) {
      console.error("Error submitting validation:", error);
      toast({
        title: "Validation Failed",
        description: "Unable to submit your validation. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="flex items-center justify-center min-h-[60vh]">
          <LoadingSpinner size="lg" text="Loading article..." />
        </div>
      </div>
    );
  }

  if (!newsItem) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 py-12 text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Article Not Found</h1>
          <p className="text-gray-600 mb-6">The requested article could not be found.</p>
          <Link
            to="/news"
            className="inline-flex items-center px-6 py-3 bg-primary text-white rounded-lg hover:bg-blue-600 transition-colors"
          >
            Back to Archive
          </Link>
        </div>
      </div>
    );
  }

  const validationOptions = [
    { value: "Ambiguous", label: "Ambiguous", color: "bg-yellow-500 hover:bg-yellow-600" },
    { value: "True News", label: "True News", color: "bg-green-500 hover:bg-green-600" },
    { value: "Fake News", label: "Fake News", color: "bg-red-500 hover:bg-red-600" }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="mb-6">
          <Link
            to="/news"
            className="inline-flex items-center text-primary hover:text-blue-600 transition-colors"
          >
            ← Back to Archive
          </Link>
        </div>

        <div className="bg-white rounded-xl shadow-lg border border-gray-200">
          <div className="p-8">
            <div className="flex items-start justify-between mb-6">
              <h1 className="text-3xl font-bold text-gray-900 font-inter">
                Article #{newsItem.index}
              </h1>
              <div className="flex space-x-2">
                <span className={`px-3 py-1 text-sm font-medium rounded-full ${
                  newsItem.pred === "Fake News" 
                    ? "bg-red-100 text-red-800" 
                    : "bg-green-100 text-green-800"
                }`}>
                  AI: {newsItem.pred}
                </span>
                {newsItem.validated && (
                  <span className="px-3 py-1 text-sm font-medium rounded-full bg-blue-100 text-blue-800">
                    Validated
                  </span>
                )}
              </div>
            </div>

            <div className="prose max-w-none mb-8">
              <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">
                {newsItem.news}
              </p>
            </div>

            {newsItem.validation_pred && (
              <div className="mb-8 p-4 bg-gray-50 rounded-lg border border-gray-200">
                <h3 className="font-medium text-gray-900 mb-2">Human Validation</h3>
                <p className="text-gray-700">
                  This article has been validated as: <span className="font-medium">{newsItem.validation_pred}</span>
                </p>
              </div>
            )}

            {!newsItem.validated && (
              <div className="border-t border-gray-200 pt-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">
                  Help Validate This Article
                </h3>
                <p className="text-gray-600 mb-6">
                  Your validation helps improve our AI model. Please select the most appropriate classification:
                </p>
                
                <div className="flex flex-wrap gap-3">
                  {validationOptions.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => handleValidation(option.value)}
                      disabled={isSubmitting}
                      className={`px-6 py-3 text-white font-medium rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${option.color}`}
                    >
                      {isSubmitting ? (
                        <div className="flex items-center space-x-2">
                          <LoadingSpinner size="sm" />
                          <span>Submitting...</span>
                        </div>
                      ) : (
                        option.label
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Success Modal */}
      {showSuccessModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6 animate-fade-in">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-green-100 rounded-full flex items-center justify-center">
                <span className="text-2xl">✅</span>
              </div>
              
              <h3 className="text-2xl font-bold text-gray-900 mb-2">
                Thank You!
              </h3>
              
              <p className="text-gray-600 mb-6">
                Your validation has been submitted for review and will help improve our AI model.
              </p>
              
              <div className="flex space-x-3">
                <Link
                  to="/news"
                  className="flex-1 px-4 py-2 bg-primary text-white rounded-lg hover:bg-blue-600 transition-colors text-center"
                  onClick={() => setShowSuccessModal(false)}
                >
                  Back to Archive
                </Link>
                <button
                  onClick={() => setShowSuccessModal(false)}
                  className="flex-1 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default NewsDetails;
