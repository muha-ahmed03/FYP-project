from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from helper import preprocessing
from models.model import predict_ensemble
import pandas as pd
import os
import nltk

nltk.download('stopwords')
nltk.download('punkt')
nltk.download("wordnet")
nltk.download("punkt_tab")

from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], 
    allow_credentials=True,
    allow_methods=["*"], 
    allow_headers=["*"], 
)

DATA_FILE = "data/predictions.csv"

if not os.path.exists(DATA_FILE):
    pd.DataFrame(columns=["news", "pred", "validation_pred", "validated"]).to_csv(DATA_FILE, index=False)

import math

def sanitize_for_json(value):
    if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
        return None
    return value

class NewsInput(BaseModel):
    subject: str
    title: str
    text: str

class ValidateInput(BaseModel):
    index: int
    validation_pred: str

@app.post("/predict")
async def predict_news(news: NewsInput):
    text = news.text.strip()
    title = news.title.strip()
    subject = news.subject.strip()
    if not text:
        raise HTTPException(status_code=400, detail="Text cannot be empty")
    
    if not title:
        raise HTTPException(status_code=400, detail="Title cannot be empty")

    preprocessed_text = preprocessing(subject + " " + title + " " + text)
    prediction = predict_ensemble(preprocessed_text)

    df = pd.read_csv(DATA_FILE)
    new_row = {
        "subject": subject,
        "title": title,
        "news": text, 
        "pred": prediction,
        "validation_pred": "",
        "validated": False
    }

    df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
    df.to_csv(DATA_FILE, index=False)

    return new_row

@app.get("/unvalidated")
async def get_unvalidated_news():
    df = pd.read_csv(DATA_FILE)
    unvalidated = df[df["validated"] == False]
    
    # Reset index to keep original index accessible
    unvalidated_with_index = unvalidated.reset_index()  # 'index' column now holds the original index
    response = unvalidated_with_index.to_dict(orient="records")

    for value in response:
        value["pred"] = sanitize_for_json(value.get("pred"))
        value["validation_pred"] = sanitize_for_json(value.get("validation_pred"))

    return response

@app.get("/all_news")
async def get_all_news():
    df = pd.read_csv(DATA_FILE)
    df_with_index = df.reset_index()
    response = df_with_index.to_dict(orient="records")
    for value in response:
        value["pred"] = sanitize_for_json(value["pred"])
        value["validation_pred"] = sanitize_for_json(value["validation_pred"])

    return response

@app.post("/validate")
async def validate_news(validation: ValidateInput):
    df = pd.read_csv(DATA_FILE)
    index = validation.index

    if index >= len(df) or index < 0:
        raise HTTPException(status_code=404, detail="Index out of range")
    
    df.at[index, "validation_pred"] = validation.validation_pred
    df.at[index, "validated"] = True
    df.to_csv(DATA_FILE, index=False)

    return {"message": "Validation updated successfully"}