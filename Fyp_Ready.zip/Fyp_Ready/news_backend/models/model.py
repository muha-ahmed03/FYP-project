import pickle
import torch
from tensorflow.keras.preprocessing.sequence import pad_sequences
from torch import nn
import joblib
from collections import Counter

# Load models
LR_model = joblib.load('models/logistic_regression_model.pkl')
DTC_model = joblib.load('models/decision_tree_model.pkl')

# Load TF-IDF Vectorizer
with open("models/tfidf_vectorizer.pkl", "rb") as f:
    vectorizer = pickle.load(f)

# Load Tokenizer
with open("models/tokenizer.pkl", "rb") as f:
    tokenizer = pickle.load(f)

# Define LSTM Classifier
class LSTMClassifier(nn.Module):
    def __init__(self, vocab_size, embed_size, hidden_size1, hidden_size2, output_size):
        super(LSTMClassifier, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embed_size, padding_idx=0)
        self.lstm1 = nn.LSTM(embed_size, hidden_size1, batch_first=True, dropout=0.25)
        self.lstm2 = nn.LSTM(hidden_size1, hidden_size2, batch_first=True, dropout=0.1)
        self.fc1 = nn.Linear(hidden_size2, 32)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(32, output_size)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        x = self.embedding(x)
        x, _ = self.lstm1(x)
        x, _ = self.lstm2(x)
        x = self.fc1(x[:, -1, :])
        x = self.relu(x)
        x = self.fc2(x)
        return self.sigmoid(x)

# Model hyperparams
embed_size = 100
hidden_size1 = 128
hidden_size2 = 64
output_size = 1
vocab_size = 10000
max_length = 300

# Load LSTM model
device = torch.device("cpu")
LSTM_model = LSTMClassifier(vocab_size, embed_size, hidden_size1, hidden_size2, output_size)
LSTM_model.load_state_dict(torch.load("models/lstm_model.pth", map_location=device))
LSTM_model.to(device)
LSTM_model.eval()

# Preprocessing
def preprocess_text_lstm(text, tokenizer, max_length):
    seq = tokenizer.texts_to_sequences([text])
    padded_seq = pad_sequences(seq, maxlen=max_length)
    return torch.tensor(padded_seq, dtype=torch.long).to(device)

def preprocess_text_tfidf(text, vectorizer):
    return vectorizer.transform([text])

# Individual model predictions
def predict_lr(text):
    processed_text = preprocess_text_tfidf(text, vectorizer)
    prediction = LR_model.predict(processed_text)[0]
    return "Fake News" if prediction == 1 else "Real News"

def predict_dtc(text):
    processed_text = preprocess_text_tfidf(text, vectorizer)
    prediction = DTC_model.predict(processed_text)[0]
    return "Fake News" if prediction == 1 else "Real News"

def predict_lstm(text):
    processed_text = preprocess_text_lstm(text, tokenizer, max_length)
    with torch.no_grad():
        output = LSTM_model(processed_text).item()
    prediction = 1 if output > 0.5 else 0
    return "Fake News" if prediction == 1 else "Real News"

# Ensemble majority vote
def predict_ensemble(text):
    predictions = [
        predict_lr(text),
        predict_dtc(text),
        predict_lstm(text)
    ]
    print(f"LR: {predictions[0]}, DTC: {predictions[1]}, LSTM: {predictions[2]}")  # Optional: for debugging
    majority_vote = Counter(predictions).most_common(1)[0][0]
    return majority_vote