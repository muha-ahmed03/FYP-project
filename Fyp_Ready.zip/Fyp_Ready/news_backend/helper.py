import re
import nltk
from bs4 import BeautifulSoup
from nltk.corpus import stopwords

# removing HTML content 
def remove_html(text):
    soup = BeautifulSoup(text, "html.parser")
    return soup.get_text()

# remove punctuations
# The function `remove_punc(text)` is using regular expressions to remove any text within square brackets and the square brackets themselves from the input `text`. The regular expression `'\[[^]]*\]'` matches any text enclosed within square brackets. The `re.sub()` function is then used to replace these matches with an empty string, effectively removing them from the text.
def remove_punc(text):
    return re.sub('\[[^]]*\]', '', text)

# remove special characters
# The function `remove_carac(text)` is using regular expressions to remove any characters that are not alphabetic (both lowercase and uppercase) from the input `text`.
def remove_carac(text):
    return re.sub("[^a-zA-Z]"," ",text)

# remove stopwords and preforming lemmatizationg (see note below)
def stop_and_lemmat(text, stopwords_set):
    lemma = nltk.WordNetLemmatizer()
    results = [lemma.lemmatize(word) for word in nltk.word_tokenize(text.lower()) if word not in stopwords_set]
    return " ".join(results)

# final function
def preprocessing(text):
    stopwords_set = set(stopwords.words("english"))
    text = remove_html(text)
    text = remove_punc(text)
    text = remove_carac(text)
    text = stop_and_lemmat(text, stopwords_set)
    return text